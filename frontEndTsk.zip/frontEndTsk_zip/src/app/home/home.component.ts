import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  gamesData: any = [];
  gamesList: any = [];
  searchText: any = '';

  p: any = 1;
  constructor(private http: HttpClient) { }
  onSearchValueChange() {
    if (this.searchText == '') {
      this.gamesData = this.gamesList;
    }
  }
  sortColumn(event) {
    const columnName: any = event.target.value;
    if (['title', 'genre', 'platform', 'editors_choice', 'score'].includes(columnName)) {
      this.gamesData.sort((a, b) => a[columnName] > b[columnName] ? 1 : -1);
    }
  }
  ngOnInit() {
    this.http.get<any[]>('https://api.jsonbin.io/b/5d45e4d789ed890b24cb25f5').subscribe(Response => {
      this.gamesData = [];
      const data = Array.from(Response, x => x);
      Response.forEach((element, index) => {
        if (element.title !== undefined) {
          element.editors_choice = element.editors_choice == 'Y'? 'Yes': 'No'; 
          this.gamesData.push(element);
          this.gamesList.push(element);
        }
      });
    });
  }

}
